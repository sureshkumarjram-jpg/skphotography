# SK Photography AI Chatbot (Dedicated Full-Page Assistant)

Comprehensive architectural and design plan to create a dedicated, brand-first full-page conversational AI Chatbot for **SK Photography / SK Production Tando Adam** (managed by Suresh Kumar), fluent in **Roman Urdu and Sindhi**, equipped with instant 2026 wedding package estimation, WhatsApp booking dispatch, and EasyPaisa/JazzCash guidance.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed in Phase 1 and will direct the implementation:
> - **Language Profile**: Primary conversational tone will be fluent **Roman Urdu & Sindhi mix** (e.g., *"Suresh Bhai ji SK Photography mein khush-aamdeed / Bhali kare aaya!"*), while seamlessly understanding Urdu and English.
> - **Screen Display & Placement**: A **Dedicated Full-Page Chat Screen** experience (`/chat` or dedicated full-viewport workspace view) with seamless one-click navigation to and from the main studio portfolio showcase.
> - **Key Brand Capabilities**: Instant 2026 wedding packages calculator, EasyPaisa/JazzCash advance deposit helper, pre-filled WhatsApp link generator directly to Suresh Kumar (`0308-3947436`), and custom event shot lists for Mehndi, Barat, and Walima.

---

## 1. Overview & Core Concept

- **What It Does**: Transforms the website experience by introducing a dedicated, high-impact conversational workspace for **SK Photography**. Clients can talk directly with the virtual studio concierge in natural Roman Urdu and Sindhi to get pricing, check dates, build custom wedding coverage quotes, explore photography styles, and send confirmed booking inquiries straight to Suresh Kumar on WhatsApp.
- **Target Audience / Persona**: Grooms, brides, families, and event hosts in Tando Adam, Shahdadpur, Sanghar, Hyderabad, Nawabshah, and across Sindh looking for premium wedding movie & photography services.
- **Key Value**: Eliminates friction and lengthy back-and-forth by giving clients instant, polite, culturally authentic Sindhi/Urdu answers 24/7, with instant calculation of 2026 packages and token payment instructions.

---

## 2. User Experience & Visual Design

### Key User Flows
1. **Entry & View Mode Switch**:
   - The user can access the chatbot either via a dedicated **"Open SK Chatbot"** button in the top navigation bar or the floating action badge.
   - When active, the application seamlessly presents the **Dedicated Full-Page Chat Screen** with a clean top bar allowing users to switch back to the **Portfolio Website** at any time without losing active conversation state.
2. **Culturally Authentic Greeting (Roman Urdu & Sindhi)**:
   - Chat initializes with warm greeting: *"Assalam-o-Alaikum & Bhali Kare Aaya! Welcome to SK Photography Tando Adam. Main Suresh Kumar ka Virtual Assistant hoon. Shadi, Barat, Mehndi ya Birthday coverage ke baare mein kya janna chahte hain?"*
   - Interactive prompt chips (e.g. *"2026 Wedding Packages rate chha aahin?"*, *"EasyPaisa ya JazzCash te advance kian moklyaan?"*, *"Barat & Drone shoot details dyo"*).
3. **Interactive Package & Price Estimation**:
   - When a user asks about rates, the chatbot renders formatted breakdown cards with estimated PKR figures (Silver PKR 35k, Gold Cinematic PKR 75k, Royal Platinum PKR 145k).
   - Generates an actionable one-click **"Send Booking to Suresh Bhai on WhatsApp"** button embedded right inside the reply.
4. **Advance Payment & Studio Visit Guidance**:
   - Answers questions regarding account titles (Suresh Kumar), mobile numbers (`0308-3947436`), and studio directions at **Chhatri Chowk, Tando Adam, Sindh**.

### Visual Identity & Theme
- **Aesthetic Direction**: Luxurious, dark cinematic studio atmosphere with warm gold highlights (`#FFCC00`, `#F59E0B`), deep obsidian surfaces (`#080808`, `#121212`), and subtle glass accents.
- **Color Palette**:
  - Dominant Canvas (60%): `#080808` & `#0D0D0D`
  - Structural Cards & Surfaces (30%): `#141414`, `#1A1A1A`, hairline gold borders `rgba(255, 204, 0, 0.25)`
  - High-Intent Accent (10%): Rich studio gold `#FFCC00` & vibrant WhatsApp emerald `#25D366`
- **Typography & Hierarchy**:
  - Display & Headings: `Cinzel` serif for prestigious cinematic brand presence.
  - Body & Chat Dialogue: `Plus Jakarta Sans` for crisp legibility across English, Roman Urdu, and Sindhi terms.
- **Motion & Interaction**:
  - Chat thread auto-scrolls smoothly to bottom.
  - Quick copy action with feedback toasts, reset thread button, and typing pulse indicators.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Full-Page Chat View with In-Memory State Preservation**
  - *Chosen Approach*: Implement a first-class screen mode toggle (`viewMode: 'website' | 'chat'`) in the root application state.
  - *Why*: Gives users an immersive, distraction-free ChatGPT-like workspace for deep consultation, while keeping the main landing page intact and ensuring conversation history is never lost when toggling between views.
  - *Alternatives Considered*: A small floating modal was already present; promoting it to a dedicated full-page screen provides far greater readability on both mobile and desktop.
- **Decision 2: Multilingual System Prompt Tuning for Roman Urdu & Sindhi**
  - *Chosen Approach*: Update the server-side Gemini system instructions to prioritize Roman Urdu and Sindhi expressions (e.g., *"Lakh Lakh Mubarak"*, *"Bhali Kare Aaya"*, *"Tando Adam Chhatri Chowk"*), while keeping responses clean, polite, and scannable with bullet points.
  - *Why*: Matches local communication habits in Sindh where wedding inquiries are predominantly made in Roman Urdu, Sindhi, or Urdu.
- **Decision 3: Server-Side Gemini 3.8 Flash SDK Integration**
  - *Chosen Approach*: Maintain all LLM generation on the Express backend (`server.ts`) via `@google/genai`, preventing API key exposure and enabling server-side telemetry and fallback caching.

---

## 4. Technical Architecture & Data Strategy

### System Component Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                           Client App                            │
│                                                                 │
│  ┌─────────────────────────────┐  ┌──────────────────────────┐  │
│  │   Navigation / Mode Bar     │  │  Global View State       │  │
│  │  [Portfolio]  [SK Chatbot]  │  │  ('website' | 'chat')    │  │
│  └──────────────┬──────────────┘  └────────────┬─────────────┘  │
│                 │                              │                │
│                 ▼                              ▼                │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │  Dedicated Full-Page Chat View (FullPageChat.tsx)         │  │
│  │  - Brand Header (SK Photography · Suresh Kumar)           │  │
│  │  - Scrollable Conversation Stream (Role: User / Model)    │  │
│  │  - Roman Urdu / Sindhi Quick Prompt Chips                 │  │
│  │  - Rich Action Cards (WhatsApp Generator, EasyPaisa Copy) │  │
│  │  - Input Form with Send Handler & Auto-Scroll             │  │
│  └──────────────────────────────┬────────────────────────────┘  │
└─────────────────────────────────┼───────────────────────────────┘
                                  │ POST /api/chat
                                  ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Express Backend (server.ts)                │
│                                                                 │
│  - Endpoint: /api/chat                                          │
│  - Model: gemini-3.8-flash                                      │
│  - System Prompt: Roman Urdu + Sindhi SK Photography Persona    │
│  - Telemetry: httpOptions { 'User-Agent': 'aistudio-build' }    │
│  - Fallback: Smart local response engine for offline spikes     │
└─────────────────────────────────────────────────────────────────┘
```

### Data Model & State
- **`ChatMessage`**:
  ```ts
  interface ChatMessage {
    id: string;
    role: 'user' | 'model';
    content: string;
    timestamp: string;
    actionLink?: string;
  }
  ```
- **Conversation State**: Managed via React state in parent or dedicated custom hook (`useStudioChat`), allowing seamless switching between the portfolio page and full-page chat without re-initializing.
- **WhatsApp Integration**: Dynamic URL composer encoding user requirements directly to `https://wa.me/923083947436?text=...`.

---

## Verification & Rollout Plan

1. **Compilation Check**: Run `compile_applet` and `lint_applet` to verify zero TypeScript and build errors.
2. **Chat Testing**: Test multi-turn conversational queries in Roman Urdu, Sindhi, and English via `/api/chat`.
3. **View Toggle Testing**: Verify switching between the full landing page and the dedicated full-page chatbot operates instantaneously.
4. **WhatsApp Link Verification**: Confirm pre-composed messages format correctly for direct contact with Suresh Kumar.
